var div=document.getElementById("content");
var gui=new gui_t(div);