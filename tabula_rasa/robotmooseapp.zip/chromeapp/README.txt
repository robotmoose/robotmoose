This is the RobotMoose Chrome App.  It connects a local Arduino with superstar.

To run the app:
	- Flash an Arduino Uno or Mega with tabula_rasa firmware, in the arduino directory.
	- Open the Chrome web browser.
	- Add the RobotMoose Backend App, via the web store (TBD!)

To edit your own version of the app:
	- Open Chrome
	- Tools -> Extensions
	- Check "Developer mode" at the top
	- Remove existing version of the app
	- "Load unpacked extension..." and navigate to this directory
	- Launch extension

To debug:
	- Tools -> Extensions
	- Inspect views "window.html"

